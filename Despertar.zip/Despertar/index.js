document.addEventListener("DOMContentLoaded", function () {
    const botaoCadastro = document.querySelector(".botao");
    
    if (botaoCadastro) {
        botaoCadastro.addEventListener("click", function (event) {
            event.preventDefault(); 

            const email = document.getElementById("email").value.trim();
            const nome = document.getElementById("nome").value.trim();
            const telefone = document.getElementById("telefone").value.trim();
            const endereco = document.getElementById("endereco").value.trim();
            const descricao = document.getElementById("descricao").value.trim();
            const senha = document.getElementById("senha").value.trim();

            if (email === "" || nome === "" || telefone === "" || endereco === "" || descricao === "" || senha === "") {
                alert("Por favor, preencha todos os campos!");
            } else {
                alert("Cadastro realizado com sucesso!");
                document.querySelector("form").reset();
            }
        });
    }

});
